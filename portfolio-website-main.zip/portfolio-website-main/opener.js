function NewTab1() {
    window.open("project/project-details-01.html");
}

function NewTab2() {
    window.open("project/project-details-02.html");
}

function NewTab3() {
    window.open("project/project-details-03.html");
}

function NewTab4() {
    window.open("project/project-details-04.html");
}

function NewTab5() {
    window.open("project/project-details-05.html");
}

function NewTab6() {
    window.open("project/project-details-06.html");
}

function NewTab7() {
    window.open("project/project-details-07.html");
}

function NewTab8() {
    window.open("project/project-details-08.html");
}

function NewTab9() {
    window.open("project/project-details-09.html");
}

function NewTab10() {
    window.open("project/project-details-10.html");
}